package cn.larry.mysearcher.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/basic")
public class BasicController {
	
//	@RequestMapping("/get")
//
//	public String getMeaasge(){
//		System.out.println("test----------------- ");
//		return "index";
//	}
//	
//	@RequestMapping("/view")
//	public ModelAndView getPage(){
//		ModelAndView mav = new ModelAndView("/view/view");
//		return mav;
//	}
}
